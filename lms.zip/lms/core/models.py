from __future__ import unicode_literals
from django.db import models

class Curso(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    sigla = models.CharField(db_column='Sigla', unique=True, max_length=5)  # Field name made lowercase.
    nome = models.CharField(db_column='Nome', unique=True, max_length=50)  # Field name made lowercase.

    def __str__(self):
        return self.nome
        
    class Meta:
        managed = True
        db_table = 'Curso'
        
class Aluno(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    ra = models.IntegerField(db_column='RA', unique=True)  # Field name made lowercase.
    nome = models.CharField(db_column='Nome', max_length=120)  # Field name made lowercase.
    email = models.EmailField(db_column='Email', max_length=80)  # Field name made lowercase.
    celular = models.CharField(db_column='Celular', max_length=11)  # Field name made lowercase.
    id_curso = models.ForeignKey('Curso', models.DO_NOTHING, db_column='ID_Curso')  # Field name made lowercase.
    sigla_curso = models.CharField(db_column='Sigla_Curso', max_length=2)  # Field name made lowercase.
    
    def __str__(self):
        return self.nome

    class Meta:
        managed = True
        db_table = 'Aluno'

class Disciplina(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    nome = models.CharField(db_column='Nome', unique=True, max_length=240)  # Field name made lowercase.
    carga_horaria = models.IntegerField(db_column='CargaHoraria')  # Field name made lowercase.
    teoria = models.DecimalField(db_column='Teoria', max_digits=3, decimal_places=0)  # Field name made lowercase.
    pratica = models.DecimalField(db_column='Pratica', max_digits=3, decimal_places=0)  # Field name made lowercase.
    ementa = models.TextField(db_column='Ementa')  # Field name made lowercase.
    competencias = models.TextField(db_column='Competencias')  # Field name made lowercase.
    habilidades = models.TextField(db_column='Habilidades')  # Field name made lowercase.
    conteudo = models.TextField(db_column='Conteudo')  # Field name made lowercase.
    bibliografia_basica = models.TextField(db_column='Bibliografia_Basica')  # Field name made lowercase.
    biliografia_complementar = models.TextField(db_column='Biliografia_Complementar')  # Field name made lowercase.

    def __str__(self):
        return self.nome
        
    class Meta:
        managed = True
        db_table = 'Disciplina'

class DisciplinaOfertada(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_disciplina = models.ForeignKey(Disciplina, models.DO_NOTHING, db_column='ID_Disciplina')  # Field name made lowercase.
    ano = models.SmallIntegerField(db_column='Ano')  # Field name made lowercase.
    semestre = models.CharField(db_column='Semestre', max_length=1)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'DisciplinaOfertada'
        unique_together = (('id_disciplina', 'ano', 'semestre'),)

class Professor(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    ra = models.IntegerField(db_column='RA', unique=True)  # Field name made lowercase.
    apelido = models.CharField(db_column='Apelido', unique=True, max_length=30)  # Field name made lowercase.
    nome = models.CharField(db_column='Nome', max_length=120)  # Field name made lowercase.
    email = models.EmailField(db_column='Email', max_length=80)  # Field name made lowercase.
    celular = models.CharField(db_column='Celular', max_length=11)  # Field name made lowercase.

    def __str__(self):
        return self.nome
        
    class Meta:
        managed = True
        db_table = 'Professor'
        
class Turma(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_disciplina_ofertada = models.ForeignKey(DisciplinaOfertada, models.DO_NOTHING, db_column='ID_DisciplinaOfertada')  # Field name made lowercase.
    identificacao_turma = models.CharField(db_column='Identificacao_Turma', max_length=1)  # Field name made lowercase.
    turno = models.CharField(db_column='Turno', max_length=15)  # Field name made lowercase.
    id_professor = models.ForeignKey(Professor, models.DO_NOTHING, db_column='ID_Professor')  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Turma'
        unique_together = (('id_disciplina_ofertada', 'id_professor'),)

class Questao(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_turma = models.ForeignKey('Turma', models.DO_NOTHING, db_column='ID_Turma')  # Field name made lowercase.
    numero = models.IntegerField(db_column='Numero')  # Field name made lowercase.
    data_limite_entrega = models.DateField(db_column='Data_Limite_Entrega')  # Field name made lowercase.
    descricao = models.TextField(db_column='Descricao')  # Field name made lowercase.
    data = models.DateField(db_column='Data')  # Field name made lowercase.

    def __str__(self):
        return self.descricao
        
    class Meta:
        managed = True
        db_table = 'Questao'
        unique_together = (('id_turma', 'numero'),)

class ArquivosQuestao(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_questao = models.ForeignKey('Questao', models.DO_NOTHING, db_column='ID_Questao')  # Field name made lowercase.
    arquivo_questao = models.CharField(db_column='Arquivo', max_length=500)  # Field name made lowercase.

    def __str__(self):
        return self.arquivo
        
    class Meta:
        managed = True
        db_table = 'ArquivosQuestao'
        unique_together = (('id_questao', 'arquivo_questao'),)

class Resposta(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_questao = models.ForeignKey(Questao, models.DO_NOTHING, db_column='ID_Questao')  # Field name made lowercase.
    id_aluno = models.ForeignKey(Aluno, models.DO_NOTHING, db_column='ID_Aluno')  # Field name made lowercase.
    data_avaliacao = models.DateField(db_column='Data_Avaliacao')  # Field name made lowercase.
    nota = models.DecimalField(db_column='Nota', max_digits=4, decimal_places=2)  # Field name made lowercase.
    avaliacao = models.TextField(db_column='Avaliacao')  # Field name made lowercase.
    descricao = models.TextField(db_column='Descricao')  # Field name made lowercase.
    data_de_envio = models.DateField(db_column='Data_de_Envio')  # Field name made lowercase.

    def __str__(self):
        return self.descricao
        
    class Meta:
        managed = True
        db_table = 'Resposta'
        unique_together = (('id_questao', 'id_aluno'),)

class ArquivosResposta(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_resposta = models.ForeignKey('Resposta', models.DO_NOTHING, db_column='ID_Resposta')  # Field name made lowercase.
    arquivo_resposta = models.CharField(db_column='Arquivo', max_length=500)  # Field name made lowercase.

    def __str__(self):
        return self.arquivo
        
    class Meta:
        managed = True
        db_table = 'ArquivosResposta'
        unique_together = (('id_resposta', 'arquivo_resposta'),)

class CursoTurma(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_curso = models.ForeignKey(Curso, models.DO_NOTHING, db_column='ID_Curso')  # Field name made lowercase.
    id_turma = models.ForeignKey('Turma', models.DO_NOTHING, db_column='ID_Turma')  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'CursoTurma'
        unique_together = (('id_curso', 'id_turma'),)

class GradeCurricular(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_curso = models.ForeignKey(Curso, models.DO_NOTHING, db_column='ID_Curso')  # Field name made lowercase.
    ano = models.SmallIntegerField(db_column='Ano')  # Field name made lowercase.
    semestre = models.CharField(db_column='Semestre', max_length=1)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'GradeCurricular'
        unique_together = (('id_curso', 'ano', 'semestre'),)

class Matricula(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_aluno = models.ForeignKey(Aluno, models.DO_NOTHING, db_column='ID_Aluno')  # Field name made lowercase.
    id_turma = models.ForeignKey('Turma', models.DO_NOTHING, db_column='ID_Turma')  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Matricula'
        unique_together = (('id_aluno', 'id_turma'),)

class Periodo(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_gradecurricular = models.ForeignKey(GradeCurricular, models.DO_NOTHING, db_column='ID_GradeCurricular')  # Field name made lowercase.
    numero = models.IntegerField(db_column='Numero')  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Periodo'
        unique_together = (('id_gradecurricular', 'numero'),)

class PeriodoDisciplina(models.Model):
    id = models.IntegerField(db_column='ID', primary_key=True)  # Field name made lowercase.
    id_periodo = models.ForeignKey(Periodo, models.DO_NOTHING, db_column='ID_Periodo')  # Field name made lowercase.
    id_disciplina = models.ForeignKey(Disciplina, models.DO_NOTHING, db_column='ID_Disciplina')  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'PeriodoDisciplina'
        unique_together = (('id_periodo', 'id_disciplina'),)