"""trabalho URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.conf import settings
from faculdade.views import *

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', index , name="Home"),
    url(r'^index', index , name="Home"),
    url(r'^sobre', sobre , name="Sobre"),
    url(r'^insc', insc , name="inscrição"),
############### PROFESSOR ###################
    url(r'^prof', prof , name="Professor"),
    url(r'^area_prof', aluno , name="Área do Professor"),
    url(r'^atvd_cadastrada', aluno , name="Atividades já cadastradas"),
    url(r'^atvd_realizada', aluno , name="Atividades já realizadas"),
    url(r'^aulas_prof', prof , name="Aulas do Professor"),
    url(r'^cancela_inscricao', prof , name="Cancelar inscrição"),
    url(r'^consultas_prof', prof , name="Consultas do professor"),
################## ALUNO ####################
    url(r'^aluno', prof , name="Aluno"),
    url(r'^area_aluno', prof , name="Área do Aluno"),
    url(r'^atividades_alunos', prof , name="Atividades do Aluno"),
    url(r'^ aulas_aluno', prof , name="Aulas para o aluno"),
    url(r'^ consiltas_aluno', prof , name="Consulta dos alunos"),
    url(r'^ inscricao_aluno', prof , name="Inscrição do aluno"),

]
