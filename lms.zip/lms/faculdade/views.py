from django.shortcuts import render
from django.shortcuts import redirect 

def index (request):
    return render(request, "index.html")
def sobre(request):
    return render(request, "sobre.html")
def insc(request):
    return render(request, "inscricao.html")
############### PROFESSOR ###################
def prof(request):
    return render(request, "professor.html")
def area_prof(request):
    return render(request, "area_professor.html")
def atvd_cadastrada(request):
    return render(request, "atv_cadastrada.html")
def atvd_realizada(request):
    return render(request, "atv_realizadas.html")
def aulas_prof(request):
    return render(request, "aulas_p.html")
def cancela_inscricao(request):
    return render(request, "cancel.html")
def consultas_prof(request):
    return render(request, "consultas_p.html")
################## ALUNO ####################
def aluno (request):
    return render(request, "aluno.html")
def area_alunos (request):
    return render(request, "area_aluno")
def atividades_alunos (request):
    return render (request, "atividades.html")
def aulas_aluno (request):
    return render (request,"aulas.html")
def consultas_aluno (request):
    return render (request, "consultas.html")
def inscricao_aluno (request):
    return render (request, "inscri_aluno")